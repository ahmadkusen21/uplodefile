<?php

// SANDI CHANNEL TV

$UserAgent= "xxx";
$Addres = "xxx";

$Cookie = "xxx";
